# Yakuake-Breath2-Dark-Minimal
The Breath2 Dark skin for Yakuake with removed titlebar. See original here: https://gitlab.manjaro.org/artwork/themes/breath2
